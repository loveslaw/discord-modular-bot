"""
CHERRY — a modular, self-hosted Discord bot.

Every feature lives in its own "cog" under cogs/. Cogs are discovered
automatically at startup and can be loaded/unloaded/reloaded on the fly
via the owner-only commands in cogs/core.py (!load, !unload, !reload),
without restarting the process. Per-server enable/disable of a module
(for regular admins, not just the bot owner) is handled separately via
/module enable|disable, stored per-guild in the database — see
utils/checks.py and cogs/core.py for how that works.
"""

import asyncio
import logging
import os
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

from utils.db import init_db

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("COMMAND_PREFIX", "!")
OWNER_IDS = {int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s: %(message)s",
)
log = logging.getLogger("cherry")

COGS_DIR = Path(__file__).parent / "cogs"


class CherryBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.voice_states = True

        super().__init__(
            command_prefix=commands.when_mentioned_or(PREFIX),
            intents=intents,
            owner_ids=OWNER_IDS or None,
            help_command=commands.DefaultHelpCommand(),
        )

    async def setup_hook(self):
        await init_db()

        # Auto-discover every cog under cogs/ (skip files starting with _)
        for file in sorted(COGS_DIR.glob("*.py")):
            if file.stem.startswith("_"):
                continue
            extension = f"cogs.{file.stem}"
            try:
                await self.load_extension(extension)
                log.info("Loaded cog: %s", extension)
            except Exception:
                log.exception("Failed to load cog: %s", extension)

        # Sync slash commands. During active development you may want to
        # restrict this to a single guild for instant updates — see README.
        try:
            synced = await self.tree.sync()
            log.info("Synced %d application command(s).", len(synced))
        except Exception:
            log.exception("Slash command sync failed.")

    async def on_ready(self):
        log.info("Logged in as %s (%s)", self.user, self.user.id)
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.listening, name=f"{PREFIX}help")
        )


async def main():
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.")

    bot = CherryBot()
    async with bot:
        await bot.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
