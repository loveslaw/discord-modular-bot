# Contributing a module

CHERRY's modules are plain discord.py cogs with two extra conventions so
they play nicely with the per-server enable/disable system. Follow this
checklist and your cog will drop straight into `cogs/`.

## Checklist

1. Pick a short, unique module name (lowercase, no spaces) — e.g. `casino`, `welcome`, `leveling`.
2. Call `register_module("yourname")` once, at import time (module-level, not inside a function).
3. Wrap **every** user-facing command with `@module_enabled("yourname")`.
4. If you need persistent storage, add your table(s) to `utils/db.py`'s
   `init_db()` — use `IF NOT EXISTS` so it's safe to run on every startup.
5. Implement an `async def setup(bot)` that does `await bot.add_cog(YourCog(bot))`.
6. Test it locally with `!load yourname`, then `!unload yourname` / `!reload yourname`
   to make sure it cleans up after itself (cancel any background tasks in `cog_unload`).

## Template

```python
"""One-line description of what this module does."""

import discord
from discord.ext import commands

from utils.checks import module_enabled, register_module
# from utils.db import get_conn   # if you need the database

MODULE = "example"
register_module(MODULE)


class Example(commands.Cog):
    """Short docstring — shows up in !help."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(description="What this command does.")
    @module_enabled(MODULE)
    async def example(self, ctx: commands.Context):
        await ctx.send("Hello from the example module!")

    def cog_unload(self):
        # Cancel background tasks / close connections here if you have any.
        pass


async def setup(bot: commands.Bot):
    await bot.add_cog(Example(bot))
```

## Ideas for community modules

- **Casino** — blackjack/slots/coinflip against the shared `economy` table
  (import `add_balance`/`get_balance` from `cogs.economy` rather than
  re-implementing balances).
- **Welcome/leave messages** — a per-guild configurable channel + message
  template, triggered off `on_member_join`/`on_member_remove`.
- **Leveling/XP** — award XP on message activity, with rank cards and a
  leaderboard, mirroring the `economy` cog's shape.
- **Reaction roles**, **starboard**, **giveaways** — all fit the same pattern.

If a module needs a third-party API key, document the env var in
`.env.example` and fail gracefully (with a clear message) when it's missing,
the way `cogs/fun.py` and `cogs/twitch_alerts.py` do.
