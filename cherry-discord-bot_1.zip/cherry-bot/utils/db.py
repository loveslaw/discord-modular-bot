"""
Shared async SQLite layer. Every cog that needs persistence goes through
here rather than opening its own connection, so the whole bot shares one
database file and one connection pool.
"""

import json
from pathlib import Path

import aiosqlite

DB_PATH = Path(__file__).parent.parent / "data" / "cherry.db"

# All modules that ship out of the box. Cogs contributed later should add
# their own name to this list (or call register_module at import time)
# so /module list and /module enable|disable know about them.
DEFAULT_MODULES = ["moderation", "music", "trivia", "fun", "twitch", "economy"]

_conn: aiosqlite.Connection | None = None


async def init_db():
    global _conn
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    _conn = await aiosqlite.connect(DB_PATH)
    _conn.row_factory = aiosqlite.Row

    await _conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id INTEGER PRIMARY KEY,
            enabled_modules TEXT NOT NULL DEFAULT '{}',
            mod_log_channel INTEGER,
            filtered_words TEXT NOT NULL DEFAULT '[]'
        );

        CREATE TABLE IF NOT EXISTS warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER NOT NULL,
            reason TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS economy (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            balance INTEGER NOT NULL DEFAULT 0,
            last_daily TEXT,
            last_work TEXT,
            PRIMARY KEY (guild_id, user_id)
        );

        CREATE TABLE IF NOT EXISTS playlists (
            guild_id INTEGER NOT NULL,
            owner_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            tracks TEXT NOT NULL DEFAULT '[]',
            PRIMARY KEY (guild_id, owner_id, name)
        );

        CREATE TABLE IF NOT EXISTS twitch_subs (
            guild_id INTEGER NOT NULL,
            twitch_login TEXT NOT NULL,
            announce_channel INTEGER NOT NULL,
            is_live INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, twitch_login)
        );
        """
    )
    await _conn.commit()


def get_conn() -> aiosqlite.Connection:
    if _conn is None:
        raise RuntimeError("Database not initialized yet — call init_db() first.")
    return _conn


async def get_guild_settings(guild_id: int) -> dict:
    conn = get_conn()
    async with conn.execute(
        "SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,)
    ) as cur:
        row = await cur.fetchone()

    if row is None:
        await conn.execute(
            "INSERT INTO guild_settings (guild_id, enabled_modules, filtered_words) VALUES (?, '{}', '[]')",
            (guild_id,),
        )
        await conn.commit()
        return {
            "guild_id": guild_id,
            "enabled_modules": {},
            "mod_log_channel": None,
            "filtered_words": [],
        }

    return {
        "guild_id": row["guild_id"],
        "enabled_modules": json.loads(row["enabled_modules"]),
        "mod_log_channel": row["mod_log_channel"],
        "filtered_words": json.loads(row["filtered_words"]),
    }


async def set_module_enabled(guild_id: int, module: str, enabled: bool):
    settings = await get_guild_settings(guild_id)
    settings["enabled_modules"][module] = enabled
    conn = get_conn()
    await conn.execute(
        "UPDATE guild_settings SET enabled_modules = ? WHERE guild_id = ?",
        (json.dumps(settings["enabled_modules"]), guild_id),
    )
    await conn.commit()


async def set_mod_log_channel(guild_id: int, channel_id: int | None):
    await get_guild_settings(guild_id)  # ensure row exists
    conn = get_conn()
    await conn.execute(
        "UPDATE guild_settings SET mod_log_channel = ? WHERE guild_id = ?",
        (channel_id, guild_id),
    )
    await conn.commit()


async def set_filtered_words(guild_id: int, words: list[str]):
    await get_guild_settings(guild_id)
    conn = get_conn()
    await conn.execute(
        "UPDATE guild_settings SET filtered_words = ? WHERE guild_id = ?",
        (json.dumps(words), guild_id),
    )
    await conn.commit()
