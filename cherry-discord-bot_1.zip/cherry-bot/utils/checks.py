"""
Per-guild module toggle.

There are two different, complementary ways this bot is "modular":

1. Process-level (owner only): cogs/core.py can !load, !unload, !reload
   an entire cog file while the bot is running. This is for you, running
   the bot — adding a brand-new module or recovering from a broken one
   without a restart.

2. Per-guild (any server admin): every command in a shipped module is
   wrapped in @module_enabled("music") (etc). A server admin can turn a
   whole module off for their server with /module disable music without
   affecting any other server, and without you touching the process at
   all. This is the toggle regular users interact with day-to-day.

Community-contributed cogs should follow the same pattern: pick a unique
module name, add it to utils.db.DEFAULT_MODULES (or call
register_module()), and wrap each command with @module_enabled("yourname").
"""

from discord.ext import commands

from utils.db import DEFAULT_MODULES, get_guild_settings


def register_module(name: str):
    """Call at import time in a contributed cog to make it visible to /module list."""
    if name not in DEFAULT_MODULES:
        DEFAULT_MODULES.append(name)


def module_enabled(name: str):
    """Command check: blocks the command if an admin disabled `name` on this server.

    Modules are enabled by default — a guild has to explicitly disable one.
    DMs always pass (there's no per-guild config to apply).
    """

    async def predicate(ctx: commands.Context) -> bool:
        if ctx.guild is None:
            return True

        settings = await get_guild_settings(ctx.guild.id)
        is_enabled = settings["enabled_modules"].get(name, True)

        if not is_enabled:
            msg = f"⚠️ The **{name}** module is disabled on this server. Ask an admin to run `/module enable {name}`."
            if ctx.interaction is not None:
                await ctx.interaction.response.send_message(msg, ephemeral=True)
            else:
                await ctx.send(msg)
            return False

        return True

    return commands.check(predicate)
