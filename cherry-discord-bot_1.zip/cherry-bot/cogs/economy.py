"""A simple per-server credits economy. Other modules (trivia, a future casino cog,
games, etc.) can award or deduct credits via the economy table directly."""

import datetime as dt
import random

import discord
from discord.ext import commands

from utils.checks import module_enabled
from utils.db import get_conn

MODULE = "economy"

DAILY_AMOUNT = 100
WORK_MIN, WORK_MAX = 20, 75
DAILY_COOLDOWN = dt.timedelta(hours=20)
WORK_COOLDOWN = dt.timedelta(hours=1)


async def get_balance(guild_id: int, user_id: int) -> int:
    conn = get_conn()
    async with conn.execute(
        "SELECT balance FROM economy WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
    ) as cur:
        row = await cur.fetchone()
    return row["balance"] if row else 0


async def add_balance(guild_id: int, user_id: int, amount: int):
    conn = get_conn()
    await conn.execute(
        """INSERT INTO economy (guild_id, user_id, balance) VALUES (?, ?, ?)
           ON CONFLICT(guild_id, user_id) DO UPDATE SET balance = balance + excluded.balance""",
        (guild_id, user_id, amount),
    )
    await conn.commit()


class Economy(commands.Cog):
    """Credits, daily/work rewards, transfers, and a leaderboard."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(description="Check your (or someone else's) credit balance.")
    @module_enabled(MODULE)
    async def balance(self, ctx: commands.Context, member: discord.Member = None):
        member = member or ctx.author
        bal = await get_balance(ctx.guild.id, member.id)
        await ctx.send(f"💰 {member.mention} has **{bal}** credits.")

    @commands.hybrid_command(description="Claim your daily credits.")
    @module_enabled(MODULE)
    async def daily(self, ctx: commands.Context):
        conn = get_conn()
        async with conn.execute(
            "SELECT last_daily FROM economy WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, ctx.author.id),
        ) as cur:
            row = await cur.fetchone()

        now = dt.datetime.utcnow()
        if row and row["last_daily"]:
            last = dt.datetime.fromisoformat(row["last_daily"])
            remaining = DAILY_COOLDOWN - (now - last)
            if remaining.total_seconds() > 0:
                hours = int(remaining.total_seconds() // 3600)
                mins = int((remaining.total_seconds() % 3600) // 60)
                return await ctx.send(f"⏳ Already claimed. Try again in {hours}h {mins}m.")

        await add_balance(ctx.guild.id, ctx.author.id, DAILY_AMOUNT)
        await conn.execute(
            "UPDATE economy SET last_daily = ? WHERE guild_id = ? AND user_id = ?",
            (now.isoformat(), ctx.guild.id, ctx.author.id),
        )
        await conn.commit()
        await ctx.send(f"✅ Claimed your daily **{DAILY_AMOUNT}** credits!")

    @commands.hybrid_command(description="Work a shift for a random amount of credits.")
    @module_enabled(MODULE)
    async def work(self, ctx: commands.Context):
        conn = get_conn()
        async with conn.execute(
            "SELECT last_work FROM economy WHERE guild_id = ? AND user_id = ?",
            (ctx.guild.id, ctx.author.id),
        ) as cur:
            row = await cur.fetchone()

        now = dt.datetime.utcnow()
        if row and row["last_work"]:
            last = dt.datetime.fromisoformat(row["last_work"])
            remaining = WORK_COOLDOWN - (now - last)
            if remaining.total_seconds() > 0:
                mins = int(remaining.total_seconds() // 60)
                return await ctx.send(f"⏳ You're on cooldown. Try again in {mins}m.")

        amount = random.randint(WORK_MIN, WORK_MAX)
        await add_balance(ctx.guild.id, ctx.author.id, amount)
        await conn.execute(
            "UPDATE economy SET last_work = ? WHERE guild_id = ? AND user_id = ?",
            (now.isoformat(), ctx.guild.id, ctx.author.id),
        )
        await conn.commit()
        await ctx.send(f"💼 You worked a shift and earned **{amount}** credits.")

    @commands.hybrid_command(description="Give some of your credits to another member.")
    @module_enabled(MODULE)
    async def pay(self, ctx: commands.Context, member: discord.Member, amount: int):
        if amount <= 0:
            return await ctx.send("Amount must be positive.")
        if member.id == ctx.author.id:
            return await ctx.send("You can't pay yourself.")

        sender_balance = await get_balance(ctx.guild.id, ctx.author.id)
        if sender_balance < amount:
            return await ctx.send("You don't have enough credits.")

        await add_balance(ctx.guild.id, ctx.author.id, -amount)
        await add_balance(ctx.guild.id, member.id, amount)
        await ctx.send(f"💸 {ctx.author.mention} paid {member.mention} **{amount}** credits.")

    @commands.hybrid_command(description="Show the richest members on this server.")
    @module_enabled(MODULE)
    async def leaderboard(self, ctx: commands.Context):
        conn = get_conn()
        async with conn.execute(
            "SELECT user_id, balance FROM economy WHERE guild_id = ? ORDER BY balance DESC LIMIT 10",
            (ctx.guild.id,),
        ) as cur:
            rows = await cur.fetchall()

        if not rows:
            return await ctx.send("Nobody has any credits yet.")

        lines = [f"{i}. <@{r['user_id']}> — {r['balance']} credits" for i, r in enumerate(rows, start=1)]
        embed = discord.Embed(title="💰 Credits Leaderboard", description="\n".join(lines), color=discord.Color.gold())
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Economy(bot))
