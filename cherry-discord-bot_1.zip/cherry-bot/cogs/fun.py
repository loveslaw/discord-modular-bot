"""Fun: gif search via the Tenor API. Needs TENOR_API_KEY in .env."""

import os
import random

import aiohttp
import discord
from discord.ext import commands

from utils.checks import module_enabled

MODULE = "fun"
TENOR_API_KEY = os.getenv("TENOR_API_KEY")
TENOR_SEARCH_URL = "https://tenor.googleapis.com/v2/search"


class Fun(commands.Cog):
    """Gif search and other lightweight fun commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="gif", description="Search for a gif.")
    @module_enabled(MODULE)
    async def gif(self, ctx: commands.Context, *, query: str):
        if not TENOR_API_KEY:
            return await ctx.send("Gif search isn't configured — set TENOR_API_KEY in .env.")

        params = {
            "q": query,
            "key": TENOR_API_KEY,
            "client_key": "cherry_bot",
            "limit": 12,
            "media_filter": "gif",
            "contentfilter": "medium",
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(TENOR_SEARCH_URL, params=params) as resp:
                data = await resp.json()

        results = data.get("results", [])
        if not results:
            return await ctx.send(f"No gifs found for `{query}`.")

        choice = random.choice(results)
        gif_url = choice["media_formats"]["gif"]["url"]

        embed = discord.Embed(title=f'Gif: "{query}"', color=discord.Color.purple())
        embed.set_image(url=gif_url)
        embed.set_footer(text="Powered by Tenor")
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Fun(bot))
