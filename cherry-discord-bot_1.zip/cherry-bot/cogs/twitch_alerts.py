"""Twitch live alerts. Polls the Helix API every 2 minutes for subscribed streamers."""

import os
import time

import aiohttp
import discord
from discord.ext import commands, tasks

from utils.checks import module_enabled
from utils.db import get_conn

MODULE = "twitch"
CLIENT_ID = os.getenv("TWITCH_CLIENT_ID")
CLIENT_SECRET = os.getenv("TWITCH_CLIENT_SECRET")


class Twitch(commands.Cog):
    """Announce when subscribed Twitch streamers go live."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._token: str | None = None
        self._token_expiry = 0
        if CLIENT_ID and CLIENT_SECRET:
            self.poll_streams.start()

    def cog_unload(self):
        self.poll_streams.cancel()

    async def _get_token(self, session: aiohttp.ClientSession) -> str | None:
        if self._token and time.time() < self._token_expiry:
            return self._token
        async with session.post(
            "https://id.twitch.tv/oauth2/token",
            params={
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "grant_type": "client_credentials",
            },
        ) as resp:
            if resp.status != 200:
                return None
            data = await resp.json()
            self._token = data["access_token"]
            self._token_expiry = time.time() + data["expires_in"] - 60
            return self._token

    @commands.hybrid_command(description="Get an alert in this channel when a Twitch streamer goes live.")
    @commands.has_permissions(manage_guild=True)
    @module_enabled(MODULE)
    async def twitchalert(self, ctx: commands.Context, twitch_username: str, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        conn = get_conn()
        await conn.execute(
            "INSERT OR REPLACE INTO twitch_subs (guild_id, twitch_login, announce_channel, is_live) VALUES (?, ?, ?, 0)",
            (ctx.guild.id, twitch_username.lower(), channel.id),
        )
        await conn.commit()
        await ctx.send(f"🔔 Will announce **{twitch_username}** going live in {channel.mention}.")

    @commands.hybrid_command(description="Stop alerting for a Twitch streamer on this server.")
    @commands.has_permissions(manage_guild=True)
    @module_enabled(MODULE)
    async def twitchunalert(self, ctx: commands.Context, twitch_username: str):
        conn = get_conn()
        await conn.execute(
            "DELETE FROM twitch_subs WHERE guild_id = ? AND twitch_login = ?",
            (ctx.guild.id, twitch_username.lower()),
        )
        await conn.commit()
        await ctx.send(f"🔕 Stopped alerts for **{twitch_username}**.")

    @tasks.loop(minutes=2)
    async def poll_streams(self):
        conn = get_conn()
        async with conn.execute("SELECT DISTINCT twitch_login FROM twitch_subs") as cur:
            rows = await cur.fetchall()
        if not rows:
            return

        logins = [r["twitch_login"] for r in rows]

        async with aiohttp.ClientSession() as session:
            token = await self._get_token(session)
            if not token:
                return

            headers = {"Client-ID": CLIENT_ID, "Authorization": f"Bearer {token}"}
            params = [("user_login", login) for login in logins]
            async with session.get(
                "https://api.twitch.tv/helix/streams", headers=headers, params=params
            ) as resp:
                if resp.status != 200:
                    return
                data = await resp.json()

            live_logins = {s["user_login"].lower(): s for s in data.get("data", [])}

            async with conn.execute("SELECT * FROM twitch_subs") as cur:
                subs = await cur.fetchall()

            for sub in subs:
                login = sub["twitch_login"]
                was_live = bool(sub["is_live"])
                is_live_now = login in live_logins

                if is_live_now and not was_live:
                    stream = live_logins[login]
                    channel = self.bot.get_channel(sub["announce_channel"])
                    if channel:
                        embed = discord.Embed(
                            title=f"{stream['user_name']} is live on Twitch!",
                            url=f"https://twitch.tv/{login}",
                            description=stream.get("title", ""),
                            color=discord.Color.purple(),
                        )
                        thumb = stream.get("thumbnail_url", "").replace("{width}", "640").replace("{height}", "360")
                        if thumb:
                            embed.set_image(url=thumb)
                        embed.set_footer(text=f"Playing {stream.get('game_name', 'something')}")
                        try:
                            await channel.send(embed=embed)
                        except discord.Forbidden:
                            pass

                await conn.execute(
                    "UPDATE twitch_subs SET is_live = ? WHERE guild_id = ? AND twitch_login = ?",
                    (1 if is_live_now else 0, sub["guild_id"], login),
                )
            await conn.commit()

    @poll_streams.before_loop
    async def before_poll(self):
        await self.bot.wait_until_ready()


async def setup(bot: commands.Bot):
    await bot.add_cog(Twitch(bot))
