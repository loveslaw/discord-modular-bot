"""Moderation: kick/ban/timeout, warnings, a bad-word message filter, and a mod log channel."""

import datetime as dt

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import module_enabled
from utils.db import (
    get_conn,
    get_guild_settings,
    set_filtered_words,
    set_mod_log_channel,
)

MODULE = "moderation"


async def log_action(bot: commands.Bot, guild: discord.Guild, embed: discord.Embed):
    settings = await get_guild_settings(guild.id)
    channel_id = settings["mod_log_channel"]
    if not channel_id:
        return
    channel = guild.get_channel(channel_id)
    if channel:
        try:
            await channel.send(embed=embed)
        except discord.Forbidden:
            pass


class Moderation(commands.Cog):
    """Kick/ban/timeout, warnings, message filtering, and mod-log."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------- config ----------

    @commands.hybrid_command(description="Set (or clear) the channel used for the moderation log.")
    @commands.has_permissions(manage_guild=True)
    @module_enabled(MODULE)
    async def modlog(self, ctx: commands.Context, channel: discord.TextChannel = None):
        await set_mod_log_channel(ctx.guild.id, channel.id if channel else None)
        await ctx.send(f"Mod log set to {channel.mention}." if channel else "Mod log disabled.")

    @commands.hybrid_command(description="Set the list of words the filter should block, comma-separated.")
    @commands.has_permissions(manage_guild=True)
    @module_enabled(MODULE)
    async def filterset(self, ctx: commands.Context, *, words: str):
        word_list = [w.strip().lower() for w in words.split(",") if w.strip()]
        await set_filtered_words(ctx.guild.id, word_list)
        await ctx.send(f"Filter now blocks {len(word_list)} word(s).")

    # ---------- actions ----------

    @commands.hybrid_command(description="Kick a member.")
    @commands.has_permissions(kick_members=True)
    @module_enabled(MODULE)
    async def kick(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        await member.kick(reason=reason)
        embed = discord.Embed(title="Member Kicked", color=discord.Color.orange())
        embed.add_field(name="User", value=f"{member} ({member.id})")
        embed.add_field(name="Moderator", value=str(ctx.author))
        embed.add_field(name="Reason", value=reason, inline=False)
        await ctx.send(embed=embed)
        await log_action(self.bot, ctx.guild, embed)

    @commands.hybrid_command(description="Ban a member.")
    @commands.has_permissions(ban_members=True)
    @module_enabled(MODULE)
    async def ban(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        await member.ban(reason=reason, delete_message_seconds=0)
        embed = discord.Embed(title="Member Banned", color=discord.Color.red())
        embed.add_field(name="User", value=f"{member} ({member.id})")
        embed.add_field(name="Moderator", value=str(ctx.author))
        embed.add_field(name="Reason", value=reason, inline=False)
        await ctx.send(embed=embed)
        await log_action(self.bot, ctx.guild, embed)

    @commands.hybrid_command(description="Timeout (mute) a member for N minutes.")
    @commands.has_permissions(moderate_members=True)
    @module_enabled(MODULE)
    async def timeout(self, ctx: commands.Context, member: discord.Member, minutes: int, *, reason: str = "No reason provided"):
        until = discord.utils.utcnow() + dt.timedelta(minutes=minutes)
        await member.timeout(until, reason=reason)
        embed = discord.Embed(title="Member Timed Out", color=discord.Color.yellow())
        embed.add_field(name="User", value=f"{member} ({member.id})")
        embed.add_field(name="Duration", value=f"{minutes} min")
        embed.add_field(name="Moderator", value=str(ctx.author))
        embed.add_field(name="Reason", value=reason, inline=False)
        await ctx.send(embed=embed)
        await log_action(self.bot, ctx.guild, embed)

    @commands.hybrid_command(description="Warn a member; warnings are stored and viewable later.")
    @commands.has_permissions(moderate_members=True)
    @module_enabled(MODULE)
    async def warn(self, ctx: commands.Context, member: discord.Member, *, reason: str = "No reason provided"):
        conn = get_conn()
        await conn.execute(
            "INSERT INTO warnings (guild_id, user_id, moderator_id, reason) VALUES (?, ?, ?, ?)",
            (ctx.guild.id, member.id, ctx.author.id, reason),
        )
        await conn.commit()
        embed = discord.Embed(title="Member Warned", color=discord.Color.gold())
        embed.add_field(name="User", value=f"{member} ({member.id})")
        embed.add_field(name="Moderator", value=str(ctx.author))
        embed.add_field(name="Reason", value=reason, inline=False)
        await ctx.send(embed=embed)
        await log_action(self.bot, ctx.guild, embed)

    @commands.hybrid_command(description="Show a member's warning history.")
    @commands.has_permissions(moderate_members=True)
    @module_enabled(MODULE)
    async def warnings(self, ctx: commands.Context, member: discord.Member):
        conn = get_conn()
        async with conn.execute(
            "SELECT moderator_id, reason, created_at FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC",
            (ctx.guild.id, member.id),
        ) as cur:
            rows = await cur.fetchall()

        if not rows:
            return await ctx.send(f"{member} has no warnings.")

        embed = discord.Embed(title=f"Warnings for {member}", color=discord.Color.gold())
        for row in rows[:15]:
            embed.add_field(
                name=row["created_at"],
                value=f"By <@{row['moderator_id']}>: {row['reason']}",
                inline=False,
            )
        await ctx.send(embed=embed)

    @commands.hybrid_command(description="Bulk-delete the last N messages in this channel.")
    @commands.has_permissions(manage_messages=True)
    @module_enabled(MODULE)
    async def purge(self, ctx: commands.Context, amount: app_commands.Range[int, 1, 100]):
        deleted = await ctx.channel.purge(limit=amount + (1 if ctx.interaction is None else 0))
        msg = await ctx.send(f"🧹 Deleted {len(deleted)} message(s).")
        if ctx.interaction is None:
            await msg.delete(delay=4)

    # ---------- message filter ----------

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None:
            return

        settings = await get_guild_settings(message.guild.id)
        if not settings["enabled_modules"].get(MODULE, True):
            return
        if not settings["filtered_words"]:
            return

        content = message.content.lower()
        hit = next((w for w in settings["filtered_words"] if w in content), None)
        if hit is None:
            return

        try:
            await message.delete()
        except discord.Forbidden:
            return

        try:
            await message.channel.send(
                f"{message.author.mention} that message was removed by the word filter.", delete_after=5
            )
        except discord.Forbidden:
            pass

        embed = discord.Embed(title="Filtered Message Removed", color=discord.Color.dark_red())
        embed.add_field(name="User", value=f"{message.author} ({message.author.id})")
        embed.add_field(name="Channel", value=message.channel.mention)
        embed.add_field(name="Matched", value=f"`{hit}`")
        embed.add_field(name="Original content", value=message.content[:1000] or "(empty)", inline=False)
        await log_action(self.bot, message.guild, embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))
