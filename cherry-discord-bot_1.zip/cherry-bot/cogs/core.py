"""
Bot management, from inside Discord.

- !load / !unload / !reload <cog>   -> owner-only, changes the running process
- !cogs                             -> owner-only, lists what's currently loaded
- /module enable|disable|list       -> any server admin, per-guild toggle
- /modlogset, handled here too since it's config, not moderation logic
"""

from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands

from utils.db import DEFAULT_MODULES, get_guild_settings, set_module_enabled

COGS_DIR = Path(__file__).parent


class Core(commands.Cog):
    """Bot & module management."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------- process-level hot reload (owner only) ----------

    @commands.command(name="load")
    @commands.is_owner()
    async def load_cog(self, ctx: commands.Context, name: str):
        try:
            await self.bot.load_extension(f"cogs.{name}")
        except Exception as e:
            await ctx.send(f"❌ Couldn't load `{name}`: `{e}`")
        else:
            await ctx.send(f"✅ Loaded `{name}`.")

    @commands.command(name="unload")
    @commands.is_owner()
    async def unload_cog(self, ctx: commands.Context, name: str):
        if name == "core":
            return await ctx.send("❌ Refusing to unload the core cog — you'd lock yourself out.")
        try:
            await self.bot.unload_extension(f"cogs.{name}")
        except Exception as e:
            await ctx.send(f"❌ Couldn't unload `{name}`: `{e}`")
        else:
            await ctx.send(f"✅ Unloaded `{name}`.")

    @commands.command(name="reload")
    @commands.is_owner()
    async def reload_cog(self, ctx: commands.Context, name: str = "all"):
        targets = (
            [f.stem for f in COGS_DIR.glob("*.py") if not f.stem.startswith("_")]
            if name == "all"
            else [name]
        )
        failed = []
        for target in targets:
            try:
                await self.bot.reload_extension(f"cogs.{target}")
            except Exception as e:
                failed.append(f"{target} (`{e}`)")

        if failed:
            await ctx.send("⚠️ Reloaded with errors:\n" + "\n".join(failed))
        else:
            await ctx.send(f"✅ Reloaded: {', '.join(targets)}")

        try:
            await self.bot.tree.sync()
        except Exception:
            pass

    @commands.command(name="cogs")
    @commands.is_owner()
    async def list_cogs(self, ctx: commands.Context):
        loaded = sorted(self.bot.extensions.keys())
        all_files = sorted(f"cogs.{f.stem}" for f in COGS_DIR.glob("*.py") if not f.stem.startswith("_"))
        lines = []
        for ext in all_files:
            lines.append(f"{'🟢' if ext in loaded else '⚪'} {ext}")
        await ctx.send("**Cogs:**\n" + "\n".join(lines))

    # ---------- per-guild module toggle (any admin) ----------

    module_group = app_commands.Group(name="module", description="Enable or disable a bot module on this server.")

    @module_group.command(name="list", description="Show which modules are enabled on this server.")
    async def module_list(self, interaction: discord.Interaction):
        settings = await get_guild_settings(interaction.guild_id)
        lines = []
        for name in DEFAULT_MODULES:
            enabled = settings["enabled_modules"].get(name, True)
            lines.append(f"{'🟢 enabled' if enabled else '🔴 disabled'} — `{name}`")
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

    @module_group.command(name="enable", description="Enable a module on this server.")
    @app_commands.describe(module="Module name, e.g. music, moderation, economy")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def module_enable(self, interaction: discord.Interaction, module: str):
        if module not in DEFAULT_MODULES:
            return await interaction.response.send_message(
                f"Unknown module `{module}`. Try one of: {', '.join(DEFAULT_MODULES)}", ephemeral=True
            )
        await set_module_enabled(interaction.guild_id, module, True)
        await interaction.response.send_message(f"✅ `{module}` enabled on this server.", ephemeral=True)

    @module_group.command(name="disable", description="Disable a module on this server.")
    @app_commands.describe(module="Module name, e.g. music, moderation, economy")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def module_disable(self, interaction: discord.Interaction, module: str):
        if module not in DEFAULT_MODULES:
            return await interaction.response.send_message(
                f"Unknown module `{module}`. Try one of: {', '.join(DEFAULT_MODULES)}", ephemeral=True
            )
        await set_module_enabled(interaction.guild_id, module, False)
        await interaction.response.send_message(f"🔴 `{module}` disabled on this server.", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Core(bot))
