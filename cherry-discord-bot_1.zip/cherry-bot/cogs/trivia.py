"""Trivia game using the Open Trivia Database (opentdb.com) — no API key needed."""

import html
import random

import aiohttp
import discord
from discord.ext import commands

from utils.checks import module_enabled
from utils.db import get_conn

MODULE = "trivia"
OPENTDB_URL = "https://opentdb.com/api.php?amount=1&type=multiple"


class TriviaView(discord.ui.View):
    def __init__(self, correct_answer: str, options: list[str], reward: int = 25, timeout: float = 20):
        super().__init__(timeout=timeout)
        self.correct_answer = correct_answer
        self.answered_by: set[int] = set()
        self.reward = reward

        for opt in options:
            self.add_item(TriviaButton(opt, opt == correct_answer))


class TriviaButton(discord.ui.Button):
    def __init__(self, label: str, is_correct: bool):
        super().__init__(label=label[:80], style=discord.ButtonStyle.secondary)
        self.is_correct = is_correct

    async def callback(self, interaction: discord.Interaction):
        view: TriviaView = self.view
        if interaction.user.id in view.answered_by:
            return await interaction.response.send_message("You already answered this one.", ephemeral=True)
        view.answered_by.add(interaction.user.id)

        if self.is_correct:
            conn = get_conn()
            await conn.execute(
                """INSERT INTO economy (guild_id, user_id, balance) VALUES (?, ?, ?)
                   ON CONFLICT(guild_id, user_id) DO UPDATE SET balance = balance + excluded.balance""",
                (interaction.guild_id, interaction.user.id, view.reward),
            )
            await conn.commit()
            await interaction.response.send_message(
                f"✅ Correct! +{view.reward} credits.", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"❌ Wrong — the answer was **{view.correct_answer}**.", ephemeral=True
            )


class Trivia(commands.Cog):
    """A quick multiple-choice trivia game that rewards economy credits."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(description="Start a trivia question. First correct answer wins credits.")
    @module_enabled(MODULE)
    async def trivia(self, ctx: commands.Context, category: int = None):
        url = OPENTDB_URL
        if category:
            url += f"&category={category}"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()

        if data.get("response_code") != 0 or not data.get("results"):
            return await ctx.send("Couldn't fetch a trivia question right now — try again in a bit.")

        q = data["results"][0]
        question = html.unescape(q["question"])
        correct = html.unescape(q["correct_answer"])
        options = [html.unescape(a) for a in q["incorrect_answers"]] + [correct]
        random.shuffle(options)

        embed = discord.Embed(
            title=f"🧠 Trivia — {html.unescape(q['category'])} ({q['difficulty']})",
            description=question,
            color=discord.Color.blurple(),
        )
        embed.set_footer(text="You have 20 seconds. First correct answer earns 25 credits.")

        view = TriviaView(correct, options)
        await ctx.send(embed=embed, view=view)


async def setup(bot: commands.Bot):
    await bot.add_cog(Trivia(bot))
