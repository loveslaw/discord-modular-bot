"""
Music: stream from YouTube or SoundCloud, per-guild queue, and saved playlists.

Uses yt-dlp to resolve a search/URL to a direct stream URL, and discord.py's
FFmpeg voice client to play it. This intentionally avoids a separate Lavalink
server so a single self-hosted bot stays a one-process deploy — for a bot
serving many large servers at once, swapping this cog for one built on
wavelink/Lavalink is the natural next step, but nothing else in the bot needs
to change to do that.
"""

import asyncio
import json
from collections import defaultdict, deque
from dataclasses import dataclass

import discord
import yt_dlp
from discord.ext import commands

from utils.checks import module_enabled
from utils.db import get_conn

MODULE = "music"

FFMPEG_OPTIONS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}

YDL_OPTIONS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "default_search": "ytsearch",
    "source_address": "0.0.0.0",
}


@dataclass
class Track:
    title: str
    url: str          # page url (for display / re-resolving)
    stream_url: str    # direct audio stream url
    requester_id: int
    duration: int = 0


def _extract(query: str, source: str = "auto") -> Track:
    """Runs in a thread; blocking yt-dlp call."""
    opts = dict(YDL_OPTIONS)
    if source == "soundcloud" and not query.startswith("http"):
        query = f"scsearch:{query}"
    elif not query.startswith("http"):
        query = f"ytsearch:{query}"

    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(query, download=False)
        if "entries" in info:
            info = info["entries"][0]
        return Track(
            title=info.get("title", "Unknown title"),
            url=info.get("webpage_url", query),
            stream_url=info["url"],
            requester_id=0,
            duration=info.get("duration") or 0,
        )


class GuildPlayer:
    """One of these per guild that's using the music module."""

    def __init__(self, bot: commands.Bot, guild: discord.Guild):
        self.bot = bot
        self.guild = guild
        self.queue: deque[Track] = deque()
        self.current: Track | None = None
        self.voice: discord.VoiceClient | None = None
        self.text_channel: discord.abc.Messageable | None = None
        self.loop_one = False

    def play_next(self, error=None):
        if error:
            print(f"Player error in {self.guild}: {error}")

        if self.loop_one and self.current:
            self.queue.appendleft(self.current)

        if not self.queue:
            self.current = None
            return

        self.current = self.queue.popleft()
        source = discord.FFmpegPCMAudio(self.current.stream_url, **FFMPEG_OPTIONS)
        self.voice.play(source, after=self.play_next)

        if self.text_channel:
            asyncio.run_coroutine_threadsafe(
                self.text_channel.send(f"▶️ Now playing: **{self.current.title}**"), self.bot.loop
            )


class Music(commands.Cog):
    """YouTube / SoundCloud playback, queueing, and playlists."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.players: dict[int, GuildPlayer] = {}

    def get_player(self, guild: discord.Guild) -> GuildPlayer:
        if guild.id not in self.players:
            self.players[guild.id] = GuildPlayer(self.bot, guild)
        return self.players[guild.id]

    async def ensure_voice(self, ctx: commands.Context) -> GuildPlayer | None:
        player = self.get_player(ctx.guild)
        player.text_channel = ctx.channel

        if ctx.author.voice is None or ctx.author.voice.channel is None:
            await ctx.send("Join a voice channel first.")
            return None

        if player.voice is None or not player.voice.is_connected():
            player.voice = await ctx.author.voice.channel.connect()
        elif player.voice.channel != ctx.author.voice.channel:
            await player.voice.move_to(ctx.author.voice.channel)

        return player

    # ---------- playback ----------

    @commands.hybrid_command(description="Play a song from YouTube or SoundCloud (URL or search terms).")
    @module_enabled(MODULE)
    async def play(self, ctx: commands.Context, *, query: str, source: str = "auto"):
        player = await self.ensure_voice(ctx)
        if player is None:
            return

        await ctx.defer() if ctx.interaction else None
        try:
            track = await asyncio.to_thread(_extract, query, source)
        except Exception as e:
            return await ctx.send(f"Couldn't find or play that: `{e}`")

        track.requester_id = ctx.author.id
        player.queue.append(track)

        if player.voice.is_playing() or player.voice.is_paused():
            await ctx.send(f"➕ Queued: **{track.title}**")
        else:
            player.play_next()
            await ctx.send(f"▶️ Playing: **{track.title}**")

    @commands.hybrid_command(description="Skip the current song.")
    @module_enabled(MODULE)
    async def skip(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if player.voice and (player.voice.is_playing() or player.voice.is_paused()):
            player.voice.stop()  # triggers play_next via the after= callback
            await ctx.send("⏭️ Skipped.")
        else:
            await ctx.send("Nothing is playing.")

    @commands.hybrid_command(description="Pause playback.")
    @module_enabled(MODULE)
    async def pause(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if player.voice and player.voice.is_playing():
            player.voice.pause()
            await ctx.send("⏸️ Paused.")

    @commands.hybrid_command(description="Resume playback.")
    @module_enabled(MODULE)
    async def resume(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if player.voice and player.voice.is_paused():
            player.voice.resume()
            await ctx.send("▶️ Resumed.")

    @commands.hybrid_command(description="Stop playback, clear the queue, and leave.")
    @module_enabled(MODULE)
    async def stop(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        player.queue.clear()
        if player.voice:
            await player.voice.disconnect()
            player.voice = None
        await ctx.send("⏹️ Stopped and left the channel.")

    @commands.hybrid_command(description="Toggle looping the current track.")
    @module_enabled(MODULE)
    async def loop(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        player.loop_one = not player.loop_one
        await ctx.send(f"🔁 Loop is now **{'on' if player.loop_one else 'off'}**.")

    @commands.hybrid_command(name="queue", description="Show the current queue.")
    @module_enabled(MODULE)
    async def show_queue(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        lines = []
        if player.current:
            lines.append(f"**Now playing:** {player.current.title}")
        if not player.queue:
            lines.append("_Queue is empty._")
        else:
            for i, track in enumerate(list(player.queue)[:15], start=1):
                lines.append(f"{i}. {track.title}")
        await ctx.send("\n".join(lines))

    # ---------- playlists (saved, per user, replayable later) ----------

    @commands.hybrid_group(name="playlist", description="Manage saved playlists.")
    @module_enabled(MODULE)
    async def playlist(self, ctx: commands.Context):
        if ctx.invoked_subcommand is None:
            await ctx.send("Use `playlist save`, `playlist load`, or `playlist list`.")

    @playlist.command(name="save", description="Save the current queue as a named playlist.")
    async def playlist_save(self, ctx: commands.Context, name: str):
        player = self.get_player(ctx.guild)
        tracks = ([player.current] if player.current else []) + list(player.queue)
        if not tracks:
            return await ctx.send("Nothing queued to save.")

        conn = get_conn()
        payload = json.dumps([{"title": t.title, "url": t.url} for t in tracks])
        await conn.execute(
            "INSERT OR REPLACE INTO playlists (guild_id, owner_id, name, tracks) VALUES (?, ?, ?, ?)",
            (ctx.guild.id, ctx.author.id, name, payload),
        )
        await conn.commit()
        await ctx.send(f"💾 Saved playlist **{name}** ({len(tracks)} tracks).")

    @playlist.command(name="load", description="Queue up a saved playlist.")
    async def playlist_load(self, ctx: commands.Context, name: str):
        conn = get_conn()
        async with conn.execute(
            "SELECT tracks FROM playlists WHERE guild_id = ? AND owner_id = ? AND name = ?",
            (ctx.guild.id, ctx.author.id, name),
        ) as cur:
            row = await cur.fetchone()

        if row is None:
            return await ctx.send(f"No playlist named **{name}** found for you.")

        player = await self.ensure_voice(ctx)
        if player is None:
            return

        saved = json.loads(row["tracks"])
        await ctx.send(f"⏳ Resolving {len(saved)} track(s)...")
        for item in saved:
            try:
                track = await asyncio.to_thread(_extract, item["url"])
                track.requester_id = ctx.author.id
                player.queue.append(track)
            except Exception:
                continue

        if not (player.voice.is_playing() or player.voice.is_paused()):
            player.play_next()
        await ctx.send(f"✅ Queued playlist **{name}**.")

    @playlist.command(name="list", description="List your saved playlists on this server.")
    async def playlist_list(self, ctx: commands.Context):
        conn = get_conn()
        async with conn.execute(
            "SELECT name FROM playlists WHERE guild_id = ? AND owner_id = ?",
            (ctx.guild.id, ctx.author.id),
        ) as cur:
            rows = await cur.fetchall()
        if not rows:
            return await ctx.send("You have no saved playlists here.")
        await ctx.send("Your playlists: " + ", ".join(r["name"] for r in rows))


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
