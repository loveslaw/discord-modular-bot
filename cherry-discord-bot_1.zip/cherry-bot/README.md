# CHERRY — a modular self-hosted Discord bot

A Python (discord.py 2.x) bot built around a real plugin system: every
feature is a "cog" that can be loaded, unloaded, and reloaded while the
bot is running, and independently enabled or disabled per server.

## Features out of the box

| Module       | Commands (prefix or slash) |
|--------------|------------------------------|
| `moderation` | `kick`, `ban`, `timeout`, `warn`, `warnings`, `purge`, `modlog`, `filterset` + auto message filter |
| `music`      | `play`, `skip`, `pause`, `resume`, `stop`, `loop`, `queue`, `playlist save/load/list` (YouTube + SoundCloud via yt-dlp) |
| `trivia`     | `trivia` — button-based multiple choice, rewards economy credits |
| `fun`        | `gif` — Tenor gif search |
| `twitch`     | `twitchalert`, `twitchunalert` — live-alert polling |
| `economy`    | `balance`, `daily`, `work`, `pay`, `leaderboard` |
| `core`       | `load`/`unload`/`reload`/`cogs` (owner, process-level), `/module enable/disable/list` (any admin, per-server) |

## Setup

1. **Create the bot application**
   - https://discord.com/developers/applications → New Application → Bot
   - Enable the **Server Members** and **Message Content** privileged intents
   - Copy the bot token

2. **Install dependencies** (Python 3.11+ recommended)
   ```bash
   python -m venv venv
   source venv/bin/activate  # venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
   Music playback also needs **FFmpeg** on your PATH (`apt install ffmpeg`, `brew install ffmpeg`, or download for Windows).

3. **Configure**
   ```bash
   cp .env.example .env
   ```
   Fill in `DISCORD_TOKEN` and `OWNER_IDS` at minimum. `TENOR_API_KEY` and the
   `TWITCH_CLIENT_ID`/`SECRET` fields are optional — those two cogs just no-op
   (or tell you they're unconfigured) without them.

4. **Invite the bot** with these scopes/permissions: `bot`, `applications.commands`,
   and at minimum Kick/Ban/Timeout Members, Manage Messages, Connect/Speak,
   Read/Send Messages.

5. **Run it**
   ```bash
   python bot.py
   ```

## How the plugin system works

There are two layers, for two different people:

- **You, running the bot** — `!load <name>`, `!unload <name>`, `!reload <name>`
  (or `!reload` with no argument to reload everything), `!cogs` to see what's
  loaded. These are owner-only and affect the whole running process
  immediately, no restart needed. Drop a new file in `cogs/` and `!load` it
  to add a feature live.

- **Any server admin** — `/module list`, `/module enable <name>`,
  `/module disable <name>`. This is a per-guild flag stored in the database;
  disabling `music` on one server has no effect on any other server, and
  doesn't require you to touch the process at all.

## Writing your own cog (casino, welcome messages, etc.)

Every cog is a normal discord.py extension, with one convention layered on
top: wrap each command in `@module_enabled("your_module_name")` so server
admins can toggle it, and register the name so `/module list` knows about it.
See `cogs/economy.py` for a fully worked example, or the minimal template
below and in `CONTRIBUTING.md`.

```python
from discord.ext import commands
from utils.checks import module_enabled, register_module

MODULE = "welcome"
register_module(MODULE)

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(description="Set the welcome message channel.")
    @commands.has_permissions(manage_guild=True)
    @module_enabled(MODULE)
    async def setwelcome(self, ctx, channel: discord.TextChannel):
        ...

async def setup(bot):
    await bot.add_cog(Welcome(bot))
```

Drop the file in `cogs/`, `!load welcome`, done — no changes to `bot.py` needed.

## Notes on the music module

Playback streams directly via `yt-dlp` + FFmpeg rather than a separate
Lavalink node, which keeps deployment to one process — good for a
self-hosted bot on a handful of servers. If you outgrow that, the cleanest
path is swapping `cogs/music.py` for a `wavelink`-based version; nothing
else in the bot depends on how music is implemented internally.
